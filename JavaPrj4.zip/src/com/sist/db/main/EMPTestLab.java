package com.sist.db.main;

import java.util.ArrayList;

import com.sist.db.dao.EmpDAO;
import com.sist.db.dao.EmpVO;

public class EMPTestLab {
	public static void main(String[] args) {
		EmpDAO dao=new EmpDAO();
		ArrayList<EmpVO> list=dao.empAllData();
		for(EmpVO vo:list) {
			System.out.println(vo.getEmpno()+" "
					+vo.getEname()+" "
					+vo.getJob()+" "
					+vo.getHiredate().toString()+" "
					+vo.getSal());
		}
	}
}
























